﻿
/* ========== site.js - custom scripts for CMCS ========== */

/* Lecturer actions */
function submitClaim() {
    alert("✅ Your claim has been submitted successfully!");
    document.querySelector(".status-message").innerText = "Status: Claim submitted.";
}

function uploadDocument() {
    alert("📂 Please select a document to upload.");
    document.querySelector(".status-message").innerText = "Status: Document uploaded.";
}

/* Coordinator actions */
function approveClaim() {
    alert("✅ Claim has been approved.");
}

function rejectClaim() {
    alert("❌ Claim has been rejected.");
}

/* Manager actions */
function finalizePayment() {
    alert("💰 Payment finalized and sent to Finance.");
}
