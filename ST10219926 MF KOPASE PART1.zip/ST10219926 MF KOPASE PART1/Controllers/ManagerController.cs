﻿using Microsoft.AspNetCore.Mvc;

namespace ST10219926_MF_KOPASE_PART1.Controllers
{
    public class ManagerController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }
    }
}

