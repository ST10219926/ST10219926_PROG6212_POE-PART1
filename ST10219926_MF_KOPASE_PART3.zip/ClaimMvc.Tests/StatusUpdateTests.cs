using ClaimMvc.Data;
using ClaimMvc.Models;
using System;
using Xunit;

namespace ClaimMvc.Tests
{
    public class StatusUpdateTests
    {
        [Fact]
        public void Can_Update_Claim_Status()
        {
            var ds = new DataStore();
            var claim = new Claim { LecturerName = "Test", Program = "Test", Hours = 1, Rate = 100 };
            ds.AddClaim(claim);

            ds.UpdateClaimStatus(claim.Id, ClaimStatus.Approved);

            Assert.Equal(ClaimStatus.Approved, ds.GetClaim(claim.Id).Status);
        }

        [Fact]
        public void Supports_File_List()
        {
            var claim = new Claim();
            claim.SupportingFiles.Add("file1.pdf");
            Assert.Single(claim.SupportingFiles);
        }
    }
}
