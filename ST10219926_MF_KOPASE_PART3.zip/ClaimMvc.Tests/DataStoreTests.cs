using ClaimMvc.Data;
using Xunit;

namespace ClaimMvc.Tests
{
    public class DataStoreTests
    {
        [Fact]
        public void DataStore_HasSeedClaims()
        {
            var ds = new DataStore();
            var claims = ds.GetClaims();
            Assert.NotEmpty(claims);
        }
    }
}
