using ClaimMvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClaimMvc.Data
{
    public class DataStore
    {
        private readonly List<Lecturer> _lecturers = new();
        private readonly List<Claim> _claims = new();

        public DataStore()
        {
            // seed data
            var a = new Lecturer { FullName = "Dr. Alice N.", Program = "Computer Science", Email = "alice@uni.edu" };
            var b = new Lecturer { FullName = "Mr. Brian M.", Program = "Information Systems", Email = "brian@uni.edu" };
            _lecturers.Add(a); _lecturers.Add(b);

            var c1 = new Claim { LecturerId = a.Id, LecturerName = a.FullName, Program = a.Program, Hours = 5.5m, Rate = 50m, Comments = "Tutorials" };
            c1.SupportingFiles.Add("sample_receipt.pdf");
            var c2 = new Claim { LecturerId = b.Id, LecturerName = b.FullName, Program = b.Program, Hours = 2m, Rate = 75m, Comments = "Exam marking" };
            _claims.Add(c1);
            _claims.Add(c2);
        }

        public IEnumerable<Lecturer> GetLecturers() => _lecturers;
        public IEnumerable<Claim> GetClaims() => _claims;
        public Claim GetClaim(Guid id) => _claims.FirstOrDefault(c => c.Id == id);
        public void AddClaim(Claim c) => _claims.Add(c);

        public void UpdateClaimStatus(Guid id, ClaimStatus status)
        {
            var claim = GetClaim(id);
            if (claim != null) claim.Status = status;
        }
    }
}
