namespace ClaimMvc.Models
{
    public enum ClaimStatus
    {
        Draft,
        Submitted,
        PendingManagerApproval,
        SentToHR,
        Approved,
        Rejected,
        Paid,
        Returned
    }

    public enum UserRole
    {
        Lecturer,
        ProgramCoordinator,
        ProjectManager,
        HR
    }
}
