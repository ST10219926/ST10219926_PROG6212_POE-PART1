using System;
using System.Collections.Generic;

namespace ClaimMvc.Models
{
    public class Claim
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid LecturerId { get; set; }
        public string LecturerName { get; set; }
        public string Program { get; set; }
        public decimal Hours { get; set; }
        public decimal Rate { get; set; }
        public decimal Total => Hours * Rate;
        public DateTime DateSubmitted { get; set; } = DateTime.UtcNow;
        public ClaimStatus Status { get; set; } = ClaimStatus.Draft;
        public string Comments { get; set; }
        public List<string> SupportingFiles { get; set; } = new List<string>();
    }
}
