using System;

namespace ClaimMvc.Models
{
    public class Lecturer
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string FullName { get; set; }
        public string Program { get; set; }
        public string Email { get; set; }
    }
}
