using Microsoft.AspNetCore.Mvc;
using ClaimMvc.Data;

namespace ClaimMvc.Controllers
{
    public class DashboardController : Controller
    {
        private readonly DataStore _store;
        public DashboardController(DataStore store) { _store = store; }

        public IActionResult Lecturer()
        {
            return View(_store.GetClaims());
        }

        public IActionResult PC()
        {
            return View(_store.GetClaims());
        }

        public IActionResult PM()
        {
            return View(_store.GetClaims());
        }

        public IActionResult HR()
        {
            return View(_store.GetClaims());
        }
    }
}
