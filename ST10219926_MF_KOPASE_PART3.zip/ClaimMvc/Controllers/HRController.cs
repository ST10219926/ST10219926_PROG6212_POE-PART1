using Microsoft.AspNetCore.Mvc;
using ClaimMvc.Data;
using ClaimMvc.Models;
using System;

namespace ClaimMvc.Controllers{
public class HRController:Controller{
private readonly DataStore _store;
public HRController(DataStore s){_store=s;}

public IActionResult Index(){return View(_store.GetClaims());}

[HttpPost]
public IActionResult Settle(Guid id){
_store.UpdateClaimStatus(id,ClaimStatus.Paid);
return RedirectToAction("Index");
}}
}
