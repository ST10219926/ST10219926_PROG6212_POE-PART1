using Microsoft.AspNetCore.Mvc;
using ClaimMvc.Data;
using ClaimMvc.Models;
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace ClaimMvc.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly DataStore _store;
        private readonly IWebHostEnvironment _env;
        public ClaimsController(DataStore store, IWebHostEnvironment env) { _store = store; _env = env; }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Claim model, IFormFile upload)
        {
            if (!ModelState.IsValid) return View(model);
            model.Id = Guid.NewGuid();

            if (upload != null && upload.Length > 0)
            {
                var uploadsFolder = Path.Combine(_env.WebRootPath, "uploads");
                Directory.CreateDirectory(uploadsFolder);
                var filename = Guid.NewGuid().ToString() + Path.GetExtension(upload.FileName);
                var filePath = Path.Combine(uploadsFolder, filename);
                using (var fs = new FileStream(filePath, FileMode.Create))
                {
                    await upload.CopyToAsync(fs);
                }
                model.SupportingFiles.Add(filename);
            }

            _store.AddClaim(model);
            return RedirectToAction("Submitted");
        }

        public IActionResult Details(Guid id)
        {
            var c = _store.GetClaim(id);
            if (c == null) return NotFound();
            return View(c);
        }
    }
}
