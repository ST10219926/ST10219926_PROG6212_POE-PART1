using Microsoft.AspNetCore.Mvc;
using ClaimMvc.Data;
using ClaimMvc.Models;
using System;

namespace ClaimMvc.Controllers
{
    public class CoordinatorController : Controller
    {
        private readonly DataStore _store;
        public CoordinatorController(DataStore store) { _store = store; }

        public IActionResult Index()
        {
            // show pending claims
            var pending = _store.GetClaims().Where(c => c.Status == ClaimStatus.Draft || c.Status == ClaimStatus.Submitted || c.Status == ClaimStatus.PendingManagerApproval);
            return View(pending);
        }

        [HttpPost]
        public IActionResult Approve(Guid id)
        {
            _store.UpdateClaimStatus(id, ClaimStatus.Approved);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Reject(Guid id)
        {
            _store.UpdateClaimStatus(id, ClaimStatus.Rejected);
            return RedirectToAction("Index");
        }
    }
}
