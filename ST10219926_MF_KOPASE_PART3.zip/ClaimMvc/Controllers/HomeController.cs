using Microsoft.AspNetCore.Mvc;
using ClaimMvc.Data;

namespace ClaimMvc.Controllers
{
    public class HomeController : Controller
    {
        private readonly DataStore _store;
        public HomeController(DataStore store) { _store = store; }

        public IActionResult Index()
        {
            var claims = _store.GetClaims();
            return View(claims);
        }
    }
}
