ClaimMvc - Enhanced
Features added:
- Auto-calculation of total in Create claim form (client-side JS)
- File upload for supporting documents (saved to wwwroot/uploads)
- Coordinator controller with Approve/Reject to change claim status
- Separate dashboards for Lecturer, PC, PM, HR
- Basic xUnit test project (ClaimMvc.Tests) checking DataStore seed data
How to run:
- dotnet restore
- dotnet run (inside ClaimMvc folder)
- dotnet test (inside ClaimMvc.Tests folder)
